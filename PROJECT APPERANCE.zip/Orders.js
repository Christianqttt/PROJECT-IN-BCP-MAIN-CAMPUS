 const ordersBody = document.getElementById('orders-body');

// Retrieve orders from localStorage
const orders = JSON.parse(localStorage.getItem('sellerOrders')) || [];

orders.forEach((order) => {
  const row = document.createElement('TR');
  row.innerHTML = `
    <td>Order #${(link unavailable)}</td>
    <td>${order.buyer}</td>
    <td>${order.items.map(item => item.name).join(', ')}</td>
    <td>${order.status}</td>
    <td>${order.stall}</td>
  `;
  ordersBody.appendChild(row);
});