 const tokenInput = document.getElementById('token');
const passwordInput = document.getElementById('password');
const authForm = document.getElementById('auth-form');

const sellerToken = 'admin';
const sellerPassword = 'password';

authForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const userToken = tokenInput.value;
    const userPassword = passwordInput.value;

    if (userToken === sellerToken && userPassword === sellerPassword) {
        window.location.href = 'Orders.html'; // Redirect to order.html
        alert('Login successful!');
    } else {
        alert('Invalid credentials!');
        tokenInput.value = '';
        passwordInput.value = '';
    }
});