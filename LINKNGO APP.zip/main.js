document.getElementById('home-btn').addEventListener('click', function() {
    window.location.href = 'index.html';
});

document.getElementById('menu-btn').addEventListener('click', function() {
    window.location.href = 'menu.html';
});

document.getElementById('cart-btn').addEventListener('click', function() {
    window.location.href = 'cart.html';
});

document.getElementById('login-btn').addEventListener('click', function() {
    window.location.href = 'login.html';
});