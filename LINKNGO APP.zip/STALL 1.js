// Sample menu data
const menuData = [
    { id: 1, name: "Cheeseburger", price: 5.99 },
    { id: 2, name: "Chicken Sandwich", price: 6.49 },
    { id: 3, name: "Veggie Burger", price: 5.49 },
];

// Function to populate menu list
function populateMenuList() {
    const menuList = document.getElementById("menu-list");
    menuData.forEach((menuItem) => {
        const listItem = document.createElement("li");
        listItem.textContent = `${menuItem.name} - $${menuItem.price}`;
        menuList.appendChild(listItem);
    });
}

// Function to handle place order button click
function handlePlaceOrderButtonClick() {
    const orderSummaryList = document.getElementById("order-summary-list");
    // TO DO: Implement logic to populate order summary list
    // and handle order placement
}

// Add event listener to place order button
document.getElementById("place-order-btn").addEventListener("click", handlePlaceOrderButtonClick);

// Populate menu list on page load
populateMenuList();