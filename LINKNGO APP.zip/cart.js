 // Get cart data from localStorage
let cartData = localStorage.getItem('cartData');
if (cartData) {
    cartData = JSON.parse(cartData);
} else {
    cartData = [];
}

// Get cart items container
const cartItemsContainer = document.querySelector('.cart-items');
const cartTotal = document.querySelector('.cart-total');

// Function to update cart total
function updateTotal() {
    const total = cartData.reduce((acc, item) => acc + (parseFloat(item.price.replace('₱', '')) * item.quantity), 0);
    cartTotal.textContent = `Total: ₱${total.toFixed(2)}`;
}

// Function to render cart items
function renderCart() {
    cartItemsContainer.innerHTML = '';
    cartData.forEach((item) => {
        const cartItem = document.createElement('LI');
        cartItem.classList.add('cart-item');
        cartItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <div class="cart-item-details">
                <h3>${item.name}</h3>
                <p>Quantity: ${item.quantity}</p>
                <p class="cart-item-price">${item.price}</p>
            </div>
            <button class="remove-btn">Remove</button>
        `;
        cartItemsContainer.appendChild(cartItem);
    });
    updateTotal();
}

// Render initial cart
renderCart();

// Add event listener for removal
cartItemsContainer.addEventListener('click', (e) => {
    if (e.target.classList.contains('remove-btn')) {
        const itemName = e.target.parentNode.querySelector('h3').textContent;
        const index = cartData.findIndex((item) => item.name === itemName);
        if (index >= 0) {
            if (cartData[index].quantity > 1) {
                cartData[index].quantity--;
            } else {
                cartData.splice(index, 1);
            }
            localStorage.setItem('cartData', JSON.stringify(cartData));
            renderCart();
        }
    }
});

// Checkout button event listener
document.getElementById('checkout-btn').addEventListener('click', () => {
    // Create order object
    const order = {
        id: Date.now(),
        buyer: 'John Doe',
        items: cartData,
        status: 'Unclaimed',
        stall: 'Stall 1'
    };

    // Store order in localStorage
    const existingOrders = JSON.parse(localStorage.getItem('orders')) || [];
    existingOrders.push(order);
    localStorage.setItem('orders', JSON.stringify(existingOrders));

    alert('Order sent to seller!');
    window.location.href = 'orders.html';
});