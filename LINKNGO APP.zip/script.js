 // Get menu items
const menuItems = document.querySelectorAll('.menu-item');

// Function to add item to cart
function addItemToCart(event) {
  const menuItem = event.target.parentNode;
  const itemName = menuItem.querySelector('h3').textContent;
  const itemPrice = menuItem.querySelector('p').textContent;
  const itemImage = menuItem.querySelector('img').src;

  let cartData = localStorage.getItem('cartData');
  if (!cartData) {
    cartData = [];
  } else {
    cartData = JSON.parse(cartData);
  }

  const existingItem = cartData.find((item) => item.name === itemName);
  if (existingItem) {
    existingItem.quantity++;
    alert(`${itemName} quantity updated.`);
  } else {
    cartData.push({ name: itemName, price: itemPrice, image: itemImage, quantity: 1 });
    alert(`${itemName} added to cart.`);
  }

  localStorage.setItem('cartData', JSON.stringify(cartData));
  location.reload();
}

menuItems.forEach((menuItem) => {
  menuItem.querySelector('.add-to-cart').addEventListener('click', addItemToCart);
});