 const checkoutBody = document.getElementById('checkout-body');
const orders = JSON.parse(localStorage.getItem('orders')) || [];

orders.forEach((order) => {
  const row = document.createElement('TR');
  row.innerHTML = `
    <td>${(link unavailable)}</td>
    <td>${order.buyer}</td>
    <td>${order.items.map(item => item.name).join(', ')}</td>
    <td>${order.status}</td>
    <td>${order.stall}</td>
  `;
  checkoutBody.appendChild(row);
});